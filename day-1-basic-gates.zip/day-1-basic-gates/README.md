# Day 1 – Basic Logic Gates

This folder contains Verilog HDL implementations of 7 basic logic gates:

- AND
- OR
- NOT
- NAND
- NOR
- XOR
- XNOR

Each gate is implemented using `assign` statements in a structural format.

## Author
Santhosh R (ECE Student – VLSI Journey)